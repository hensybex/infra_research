# Recommendation letters

Three partner recommendation letters live in Google Docs for now.
Use the in-app links or drop PDFs here when exporting for offline handoffs.
