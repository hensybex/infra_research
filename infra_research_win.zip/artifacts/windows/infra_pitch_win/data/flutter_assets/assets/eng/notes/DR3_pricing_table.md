# Pricing Table (Summary)

| Scenario | Total Value (₽M) | Total Value ($M) | Base Retainer (₽M) | Success Fees (₽M) | All-in (₽M) | Value/Cost (x) |
| --- | --- | --- | --- | --- | --- | --- |
| Conservative | 72.6 | 0.9 | 36.0 | 0.0 | 36.0 | 6.6 |
| Expected | 192.6 | 2.4 | 36.0 | 8.6 | 44.6 | 17.6 |
| Aggressive | 329.7 | 4.1 | 36.0 | 20.8 | 56.8 | 30.2 |
