# AWS Partner Agent Factory

- Source: https://aws.amazon.com/blogs/apn/aws-generative-ai-innovation-center-launches-partner-agent-factory/
- Captured: 2025-11-05T13:42:42Z

Summary:
- The AWS Generative AI Innovation Center launched the Partner Agent Factory to co-innovate enterprise-grade AI agents with Partner Innovation Alliance members.
